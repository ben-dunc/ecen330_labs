#ifndef CONFIG_LAB7
#define CONFIG_LAB7

#define CONFIG_TIMER_PERIOD 0.05

#endif /* CONFIG_LAB7 */
